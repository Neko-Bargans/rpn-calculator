Here are some points of enhancements to do:
* Variabilize the database uri: currently i hardcoded a sqlite uri to gain time, but it would be nice to varibilize it with an env var
* The tests are not finished: i started creating some unit tests on my services, but they are not complete. Additionally some integration/component tests who would call and test the API would be great
* Enhance the swagger documentation with more details, description, etc... To be more user friendly
* Enhance the pyproject.toml with project description and requirements directly there. Currently i used requirements.txt file to be faster.